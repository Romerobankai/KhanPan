'use strict';
const test = require('node:test'), assert = require('node:assert');
const server = require('../server');
let base;
test.before(() => new Promise(ok => server.listen(0, () => { base = 'http://localhost:' + server.address().port; ok(); })));
test.after(() => server.close());
test('catalog is labelled demo', async () => {
  const j = await (await fetch(base + '/api/catalog')).json();
  assert.strictEqual(j.meta.demo, true); assert.ok(j.products.length > 0);
});
test('basket validates input', async () => {
  const r = await fetch(base + '/api/basket', { method: 'POST', body: JSON.stringify({ items: [{ product: 'nope', qty: 1 }] }) });
  assert.strictEqual(r.status, 400);
});
test('meals endpoint ranks recipes', async () => {
  const j = await (await fetch(base + '/api/meals', { method: 'POST', body: JSON.stringify({ have: ['rice', 'tomato', 'onion'], servings: 2 }) })).json();
  assert.ok(j.meals.length > 0);
});
