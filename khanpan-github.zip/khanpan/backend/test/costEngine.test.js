'use strict';
const test = require('node:test'), assert = require('node:assert');
const { quote, compareProduct, optimizeBasket, deliveryFor } = require('../costEngine');
const mk = (offers, sellers) => ({ products: [{ id: 'a', perishable: true }, { id: 'b', perishable: false }], sellers, offers, recipes: [] });
const S = (id, delivery, free, min = 0) => ({ id, name: id, delivery, freeDeliveryAbove: free, minOrder: min });

test('cheapest headline price is not cheapest total (brief example)', () => {
  const d = mk([{ seller: 'A', product: 'b', price: 30, packQty: 1 }, { seller: 'B', product: 'b', price: 35, packQty: 1 },
    { seller: 'C', product: 'b', price: 28, packQty: 1 }], [S('A', 25, 999), S('B', 0, 999), S('C', 40, 999)]);
  const r = compareProduct('b', 1, d);
  assert.deepStrictEqual(r.quotes.map(q => q.total), [35, 55, 68]);
  assert.strictEqual(r.best.seller, 'B');
});
test('free delivery threshold', () => {
  assert.strictEqual(deliveryFor(S('x', 20, 100), 99), 20);
  assert.strictEqual(deliveryFor(S('x', 20, 100), 100), 0);
});
test('packs round up and surplus is valued', () => {
  const q = quote({ price: 100, packQty: 5 }, S('x', 0, 0), 1);
  assert.strictEqual(q.packs, 1); assert.strictEqual(q.surplus, 4);
  assert.strictEqual(q.unitPrice, 20); assert.strictEqual(q.surplusValue, 80);
});
test('perishable bulk pack is flagged and not recommended', () => {
  const d = mk([{ seller: 'A', product: 'a', price: 50, packQty: 5 }, { seller: 'B', product: 'a', price: 60, packQty: 1 }],
    [S('A', 0, 0), S('B', 0, 0)]);
  const r = compareProduct('a', 1, d);
  assert.strictEqual(r.quotes.find(q => q.seller === 'A').wasteRisk, true);
  assert.strictEqual(r.best.seller, 'B');
});
test('rejects non-positive quantity', () => assert.throws(() => quote({ price: 1, packQty: 1 }, S('x', 0, 0), 0)));
test('basket: split rejected when delivery makes it dearer', () => {
  const d = mk([{ seller: 'A', product: 'a', price: 10, packQty: 1 }, { seller: 'A', product: 'b', price: 12, packQty: 1 },
    { seller: 'B', product: 'a', price: 9, packQty: 1 }, { seller: 'B', product: 'b', price: 11, packQty: 1 }],
    [S('A', 0, 0), S('B', 30, 999)]);
  const r = optimizeBasket([{ product: 'a', qty: 1 }, { product: 'b', qty: 1 }], d);
  assert.strictEqual(r.plan.stores, 1); assert.strictEqual(r.plan.total, 22);
});
test('basket: split chosen when genuinely cheaper', () => {
  const d = mk([{ seller: 'A', product: 'a', price: 10, packQty: 1 }, { seller: 'A', product: 'b', price: 100, packQty: 1 },
    { seller: 'B', product: 'a', price: 50, packQty: 1 }, { seller: 'B', product: 'b', price: 20, packQty: 1 }],
    [S('A', 0, 0), S('B', 0, 0)]);
  const r = optimizeBasket([{ product: 'a', qty: 1 }, { product: 'b', qty: 1 }], d);
  assert.strictEqual(r.plan.total, 30); assert.strictEqual(r.plan.stores, 2); assert.strictEqual(r.savingsVsSingle, 40);
});
test('basket: reports products nobody sells', () => {
  const d = mk([{ seller: 'A', product: 'a', price: 10, packQty: 1 }], [S('A', 0, 0)]);
  assert.deepStrictEqual(optimizeBasket([{ product: 'a', qty: 1 }, { product: 'zzz', qty: 1 }], d).unavailable, ['zzz']);
});
