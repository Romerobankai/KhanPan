'use strict';
// Cost engine: total payable cost, unit price, surplus/waste, and basket optimisation.
const r2 = n => Math.round(n * 100) / 100;

function deliveryFor(seller, subtotal) {
  if (subtotal <= 0) return 0;
  return subtotal >= seller.freeDeliveryAbove ? 0 : seller.delivery;
}

function quote(offer, seller, qty) {
  if (!(qty > 0)) throw new Error('qty must be a positive number');
  const packs = Math.ceil(qty / offer.packQty - 1e-9);
  const subtotal = r2(packs * offer.price);
  const delivery = deliveryFor(seller, subtotal);
  const unitPrice = r2(offer.price / offer.packQty);
  const bought = r2(packs * offer.packQty);
  const surplus = r2(bought - qty);
  return { seller: seller.id, sellerName: seller.name, packs, packQty: offer.packQty,
    subtotal, delivery, total: r2(subtotal + delivery), unitPrice,
    surplus, surplusValue: r2(surplus * unitPrice), surplusShare: r2(surplus / bought),
    meetsMinimum: subtotal >= seller.minOrder, updatedAt: offer.updatedAt };
}

// Compare one product across sellers. Perishables with >50% surplus get a wasteRisk flag
// and are not recommended unless nothing else exists.
function compareProduct(productId, qty, data) {
  const product = data.products.find(p => p.id === productId);
  if (!product) throw new Error('unknown product: ' + productId);
  const quotes = data.offers.filter(o => o.product === productId).map(o => {
    const q = quote(o, data.sellers.find(s => s.id === o.seller), qty);
    q.wasteRisk = !!product.perishable && q.surplusShare > 0.5;
    return q;
  }).sort((a, b) => a.total - b.total || a.unitPrice - b.unitPrice);
  const best = quotes.find(q => !q.wasteRisk) || quotes[0] || null;
  return { product, qty, quotes, best };
}

function evalPlan(assign, items, data) {
  const bySeller = {};
  for (const it of items) {
    const sid = assign[it.product];
    const offer = data.offers.find(o => o.product === it.product && o.seller === sid);
    const seller = data.sellers.find(s => s.id === sid);
    const q = quote(offer, seller, it.qty);
    (bySeller[sid] ||= { seller: sid, sellerName: seller.name, lines: [], subtotal: 0 })
      .lines.push({ product: it.product, qty: it.qty, packs: q.packs, packQty: q.packQty, cost: q.subtotal });
    bySeller[sid].subtotal = r2(bySeller[sid].subtotal + q.subtotal);
  }
  let total = 0, valid = true;
  const orders = Object.values(bySeller).map(o => {
    const s = data.sellers.find(x => x.id === o.seller);
    o.delivery = deliveryFor(s, o.subtotal);
    o.meetsMinimum = o.subtotal >= s.minOrder;
    o.total = r2(o.subtotal + o.delivery);
    if (!o.meetsMinimum) valid = false;
    total += o.total;
    return o;
  });
  return { orders, total: r2(total), valid, stores: orders.length };
}

// Basket optimiser: candidates are every single-store plan plus a greedy split improved by
// local search. Delivery fees and minimum orders are counted, so splitting is only chosen
// when it actually costs less.
function optimizeBasket(items, data) {
  const unavailable = [];
  const live = items.filter(it => {
    const ok = data.offers.some(o => o.product === it.product);
    if (!ok) unavailable.push(it.product);
    return ok;
  });
  if (!live.length) return { plan: null, singleStore: null, unavailable, savingsVsSingle: 0 };
  const sellersFor = p => data.offers.filter(o => o.product === p).map(o => o.seller);
  const score = p => p.total + (p.valid ? 0 : 1e6);
  const singles = [];
  for (const s of data.sellers) {
    if (live.every(it => sellersFor(it.product).includes(s.id))) {
      singles.push(evalPlan(Object.fromEntries(live.map(it => [it.product, s.id])), live, data));
    }
  }
  const singleStore = singles.sort((a, b) => score(a) - score(b))[0] || null;
  let assign = {};
  for (const it of live) {
    assign[it.product] = sellersFor(it.product).map(sid => ({ sid,
      c: quote(data.offers.find(o => o.product === it.product && o.seller === sid),
               data.sellers.find(s => s.id === sid), it.qty).subtotal }))
      .sort((a, b) => a.c - b.c)[0].sid;
  }
  let best = evalPlan(assign, live, data), improved = true;
  while (improved) {
    improved = false;
    for (const it of live) for (const sid of sellersFor(it.product)) {
      const t = { ...assign, [it.product]: sid };
      const p = evalPlan(t, live, data);
      if (score(p) < score(best) - 1e-9) { best = p; assign = t; improved = true; }
    }
  }
  const plan = singleStore && score(singleStore) <= score(best) ? singleStore : best;
  return { plan, singleStore, unavailable,
    savingsVsSingle: singleStore ? r2(Math.max(0, singleStore.total - plan.total)) : 0 };
}

// Recipe suggestions from what the user has; expiring items get a ranking boost.
function suggestMeals({ have = [], expiring = [], servings = 2 }, data) {
  return data.recipes.map(r => {
    const f = servings / r.servings;
    const ings = r.ingredients.map(i => ({ product: i.product, qty: r2(i.qty * f) }));
    const missing = ings.filter(i => !have.includes(i.product));
    const usesExpiring = ings.filter(i => expiring.includes(i.product)).map(i => i.product);
    const coverage = r2((ings.length - missing.length) / ings.length);
    const opt = missing.length ? optimizeBasket(missing, data) : null;
    return { name: r.name, time: r.time, servings, coverage, usesExpiring, missing,
      missingCost: opt && opt.plan ? opt.plan.total : 0, ingredients: ings };
  }).sort((a, b) => (b.usesExpiring.length - a.usesExpiring.length) ||
                    (b.coverage - a.coverage) || (a.missingCost - b.missingCost));
}

module.exports = { quote, compareProduct, optimizeBasket, suggestMeals, deliveryFor };
