'use strict';
// Zero-dependency server (Node 18+). Serves the frontend and a small JSON API.
// Retailer integrations would be added as adapters returning data in the shape of data/sample-data.json.
const http = require('http'), fs = require('fs'), path = require('path');
const engine = require('./costEngine');
const data = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', 'sample-data.json'), 'utf8'));
const FRONT = path.join(__dirname, '..', 'frontend');
const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json' };

const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
const body = req => new Promise((ok, no) => { let s = ''; req.on('data', c => { s += c; if (s.length > 1e5) req.destroy(); });
  req.on('end', () => { try { ok(s ? JSON.parse(s) : {}); } catch (e) { no(new Error('invalid JSON')); } }); });
const cleanItems = a => {
  if (!Array.isArray(a) || a.length > 50) throw new Error('items must be an array (max 50)');
  return a.map(i => { const qty = Number(i.qty);
    if (!data.products.some(p => p.id === i.product) || !(qty > 0)) throw new Error('invalid item: ' + JSON.stringify(i));
    return { product: i.product, qty }; });
};

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try {
    if (url.pathname === '/api/catalog') return send(res, 200, { meta: data.meta, products: data.products, sellers: data.sellers });
    if (url.pathname === '/api/compare') {
      const qty = Number(url.searchParams.get('qty') || 1);
      return send(res, 200, engine.compareProduct(url.searchParams.get('product'), qty, data));
    }
    if (url.pathname === '/api/basket' && req.method === 'POST') {
      const b = await body(req); return send(res, 200, engine.optimizeBasket(cleanItems(b.items), data));
    }
    if (url.pathname === '/api/meals' && req.method === 'POST') {
      const b = await body(req);
      return send(res, 200, { meta: data.meta, meals: engine.suggestMeals({ have: b.have || [], expiring: b.expiring || [],
        servings: Math.min(20, Math.max(1, Number(b.servings) || 2)) }, data) });
    }
    if (url.pathname.startsWith('/api/')) return send(res, 404, { error: 'not found' });
    const rel = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
    const file = path.normalize(path.join(FRONT, rel));
    if (!file.startsWith(FRONT) || !fs.existsSync(file)) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'text/plain' }); fs.createReadStream(file).pipe(res);
  } catch (e) { send(res, 400, { error: e.message }); }
});
if (require.main === module) {
  const port = process.env.PORT || 3000;
  server.listen(port, () => console.log('KhanPan running at http://localhost:' + port));
}
module.exports = server;
