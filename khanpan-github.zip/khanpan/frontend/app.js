'use strict';
// State lives in localStorage (per browser). A real deployment would move it behind accounts + a database.
const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const inr = n => '₹' + (Math.round(n * 100) / 100).toLocaleString('en-IN');
const load = (k, d) => { try { return JSON.parse(localStorage.getItem('khanpan.' + k)) ?? d; } catch (e) { return d; } };
const S = { list: load('list', []), kitchen: load('kitchen', []), spend: load('spend', []), budget: load('budget', 2000),
  planned: null, tab: 'discover', q: '', cat: 'all', servings: 2 };
const save = () => ['list', 'kitchen', 'spend', 'budget'].forEach(k => localStorage.setItem('khanpan.' + k, JSON.stringify(S[k])));
let CAT;
const prod = id => CAT.products.find(p => p.id === id);
const name = id => (prod(id) || { name: id }).name;
const unit = id => (prod(id) || { unit: '' }).unit;
async function api(path, body) {
  const r = await fetch(path, body ? { method: 'POST', body: JSON.stringify(body) } : undefined);
  const j = await r.json(); if (!r.ok) throw new Error(j.error || 'Request failed'); return j;
}
const opts = () => CAT.products.map(p => `<option value="${p.id}">${esc(p.name)} (${p.unit})</option>`).join('');
const daysTo = d => d ? Math.ceil((new Date(d) - new Date(new Date().toDateString())) / 864e5) : null;
function addToList(id, qty) {
  const e = S.list.find(i => i.product === id && !i.done);
  if (e) e.qty = Math.round((e.qty + qty) * 100) / 100; else S.list.push({ product: id, qty, done: false });
  S.planned = null; save();
}

const views = {
  async discover() {
    const cats = ['all', ...new Set(CAT.products.map(p => p.category))];
    const shown = CAT.products.filter(p => (S.cat === 'all' || p.category === S.cat) && p.name.toLowerCase().includes(S.q.toLowerCase()));
    const res = await Promise.all(shown.map(p => api('/api/compare?product=' + p.id + '&qty=1')));
    return `<div class="row"><input class="grow" id="q" type="search" placeholder="Search ingredients" value="${esc(S.q)}" aria-label="Search">
      <select id="cat" aria-label="Category">${cats.map(c => `<option ${c === S.cat ? 'selected' : ''}>${c}</option>`).join('')}</select></div>
      <p class="mute">Prices for 1 unit, including delivery. Best option skips bulk packs that would spoil.</p>` +
      (res.length ? res.map(r => { const b = r.best, p = r.product;
        return `<div class="card"><div class="row"><strong class="grow">${esc(p.name)}</strong>${p.perishable ? '<span class="badge">fresh</span>' : ''}</div>
        ${b ? `<div class="price">${inr(b.total)} <span class="mute">at ${esc(b.sellerName)}</span></div>
        <div class="mute">${inr(b.unitPrice)}/${p.unit} · item ${inr(b.subtotal)} + delivery ${inr(b.delivery)}</div>
        <details><summary>Compare ${r.quotes.length} sellers</summary><table><tr><th>Seller</th><th>Total</th><th>Per ${p.unit}</th><th></th></tr>
        ${r.quotes.map(q => `<tr><td>${esc(q.sellerName)}</td><td>${inr(q.total)}</td><td>${inr(q.unitPrice)}</td>
        <td>${q.wasteRisk ? '<span class="badge warn">waste risk</span>' : q === b ? '<span class="badge">best</span>' : ''}</td></tr>`).join('')}</table>
        <p class="mute">Demo prices, updated ${esc(b.updatedAt)}.</p></details>` : '<div class="mute">No seller has this yet.</div>'}
        <div class="row"><input type="number" min="0.05" step="0.05" value="1" id="n-${p.id}" style="width:80px" aria-label="Quantity of ${esc(p.name)}">
        <button data-add="${p.id}">Add to list</button></div></div>`; }).join('') : '<div class="empty">No ingredients match. Clear the search or pick another category.</div>');
  },
  async meals() {
    const have = S.kitchen.map(k => k.product), expiring = S.kitchen.filter(k => { const d = daysTo(k.expiry); return d !== null && d <= 3; }).map(k => k.product);
    const j = await api('/api/meals', { have, expiring, servings: S.servings });
    return `<div class="row"><label>Servings <input id="serv" type="number" min="1" max="20" value="${S.servings}" style="width:70px"></label></div>
      <p class="mute">Based on ${have.length} item(s) in My Kitchen${expiring.length ? ', using items that expire soon first' : ''}.</p>` +
      (have.length ? '' : '<div class="empty">Add what you have in the Kitchen tab to see how much of each meal you can already make.</div>') +
      j.meals.map((m, i) => `<div class="card"><div class="row"><strong class="grow">${esc(m.name)}</strong><span class="mute">${m.time}</span></div>
        <div class="mute">You have ${Math.round(m.coverage * 100)}% of the ingredients${m.usesExpiring.length ? ' · uses ' + m.usesExpiring.map(name).join(', ') + ' before it expires' : ''}</div>
        ${m.missing.length ? `<div>Need: ${m.missing.map(x => `${esc(name(x.product))} ${x.qty} ${unit(x.product)}`).join(', ')}</div>
        <div class="price">${inr(m.missingCost)} <span class="mute">to buy the rest (best basket)</span></div>
        <button class="primary" data-meal="${i}">Add missing to list</button>` : '<span class="badge">Ready to cook</span>'}</div>`).join('');
  },
  async list() {
    if (!S.list.length) return '<div class="empty">Your list is empty. Add items from Discover or pick a meal.</div>';
    const open = S.list.filter(i => !i.done);
    let out = S.list.map((i, k) => `<div class="card row"><input type="checkbox" data-done="${k}" ${i.done ? 'checked' : ''} aria-label="Bought ${esc(name(i.product))}">
      <span class="grow ${i.done ? 'done' : ''}">${esc(name(i.product))}</span>
      <input type="number" min="0.05" step="0.05" value="${i.qty}" data-qty="${k}" style="width:80px" aria-label="Quantity"> <span class="mute">${unit(i.product)}</span>
      <button data-del="${k}" aria-label="Remove ${esc(name(i.product))}">Remove</button></div>`).join('');
    out += '<button class="primary" id="opt">Find best basket</button>';
    if (open.length) {
      const j = await api('/api/basket', { items: open.map(i => ({ product: i.product, qty: i.qty })) });
      if (j.plan) { S.planned = j.plan.total;
        out += `<h2>Suggested purchase: ${inr(j.plan.total)}</h2>` + (j.plan.valid ? '' : '<p class="badge warn">One order is below the seller minimum</p>') +
          j.plan.orders.map(o => `<div class="card"><strong>${esc(o.sellerName)}</strong> <span class="mute">item ${inr(o.subtotal)} + delivery ${inr(o.delivery)}</span>
          <div class="mute">${o.lines.map(l => `${esc(name(l.product))} (${l.packs}×${l.packQty} ${unit(l.product)})`).join(', ')}</div></div>`).join('') +
          (j.savingsVsSingle > 0 ? `<p>Splitting across ${j.plan.stores} stores saves ${inr(j.savingsVsSingle)} versus the best single store.</p>`
            : j.plan.stores > 1 ? '' : '<p class="mute">One store is cheapest once delivery is counted.</p>');
      }
      if (j.unavailable.length) out += `<p class="badge warn">No demo seller for: ${j.unavailable.map(name).join(', ')}</p>`;
      out += '<p class="mute">Estimates from demo data. Real ordering needs a retailer integration (see README).</p>' +
        '<button id="bought">I bought these: log spend and add to Kitchen</button>';
    }
    return out;
  },
  async kitchen() {
    const rows = S.kitchen.map((k, i) => { const d = daysTo(k.expiry), low = k.low != null && k.qty <= k.low;
      return `<div class="card row"><strong class="grow">${esc(name(k.product))}</strong><span>${k.qty} ${unit(k.product)}</span>
      ${d !== null ? `<span class="badge ${d <= 3 ? 'warn' : ''}">${d < 0 ? 'expired' : d + ' day(s) left'}</span>` : ''}
      ${low ? '<span class="badge warn">running low</span><button data-rebuy="' + i + '">Add to list</button>' : ''}
      <button data-kdel="${i}" aria-label="Remove">Remove</button></div>`; }).join('');
    return `<h2>Add to My Kitchen</h2><div class="row"><select id="kp" class="grow">${opts()}</select>
      <input id="kq" type="number" min="0" step="0.05" placeholder="Qty" style="width:80px"><input id="ke" type="date" aria-label="Expiry date">
      <input id="kl" type="number" min="0" step="0.05" placeholder="Low at" style="width:80px"><button class="primary" id="kadd">Add</button></div>
      <p class="mute">Expiry and "low at" are optional. Reminders use only dates you enter.</p>` +
      (rows || '<div class="empty">Nothing here yet. Add what you have at home.</div>');
  },
  async budget() {
    const spent = S.spend.reduce((a, b) => a + b.amount, 0), pct = Math.min(100, spent / S.budget * 100);
    return `<div class="card"><div class="row"><label class="grow">Budget (₹) <input id="bud" type="number" min="0" value="${S.budget}"></label></div>
      <div class="bar ${spent > S.budget ? 'over' : ''}"><i style="width:${pct}%"></i></div>
      <p>Spent ${inr(spent)} of ${inr(S.budget)}${S.planned != null ? ` · planned basket ${inr(S.planned)}${spent + S.planned > S.budget ? ' <span class="badge warn">over budget</span>' : ''}` : ''}</p></div>
      <h2>Log a purchase</h2><div class="row"><input id="sn" class="grow" placeholder="What was it?"><input id="sa" type="number" min="0" placeholder="₹" style="width:90px"><button class="primary" id="sadd">Log</button></div>
      <p class="mute">Spend is what you enter. Nothing is tracked automatically.</p>` +
      (S.spend.length ? S.spend.slice().reverse().map(s => `<div class="card row"><span class="grow">${esc(s.note)} <span class="mute">${esc(s.date)}</span></span><strong>${inr(s.amount)}</strong></div>`).join('')
        : '<div class="empty">No purchases logged yet.</div>');
  }
};

async function render() {
  document.querySelectorAll('nav button').forEach(b => b.classList.toggle('on', b.dataset.tab === S.tab));
  try { $('#view').innerHTML = await views[S.tab](); } catch (e) { $('#view').innerHTML = `<div class="empty">Something went wrong: ${esc(e.message)}. Check the server is running, then reload.</div>`; }
}
document.addEventListener('click', async e => {
  const t = e.target, d = t.dataset || {};
  if (d.tab) { S.tab = d.tab; return render(); }
  if (d.add) { const q = parseFloat($('#n-' + d.add).value); if (q > 0) { addToList(d.add, q); t.textContent = 'Added'; } return; }
  if (d.meal !== undefined) { const j = await api('/api/meals', { have: S.kitchen.map(k => k.product), servings: S.servings });
    const m = j.meals[+d.meal]; m.missing.forEach(x => addToList(x.product, x.qty)); S.tab = 'list'; return render(); }
  if (d.del !== undefined) { S.list.splice(+d.del, 1); S.planned = null; save(); return render(); }
  if (d.kdel !== undefined) { S.kitchen.splice(+d.kdel, 1); save(); return render(); }
  if (d.rebuy !== undefined) { const k = S.kitchen[+d.rebuy]; addToList(k.product, Math.max(1, k.low || 1)); t.textContent = 'Added'; return; }
  if (t.id === 'opt') return render();
  if (t.id === 'kadd') { const q = parseFloat($('#kq').value); if (!(q >= 0)) return alert('Enter a quantity.');
    const l = parseFloat($('#kl').value); S.kitchen.push({ product: $('#kp').value, qty: q, expiry: $('#ke').value || null, low: isNaN(l) ? null : l }); save(); return render(); }
  if (t.id === 'sadd') { const a = parseFloat($('#sa').value); if (!(a > 0)) return alert('Enter an amount above 0.');
    S.spend.push({ note: $('#sn').value || 'Groceries', amount: a, date: new Date().toISOString().slice(0, 10) }); save(); return render(); }
  if (t.id === 'bought') { const open = S.list.filter(i => !i.done);
    open.forEach(i => { const k = S.kitchen.find(x => x.product === i.product); if (k) k.qty = Math.round((k.qty + i.qty) * 100) / 100; else S.kitchen.push({ product: i.product, qty: i.qty, expiry: null, low: null }); });
    if (S.planned > 0) S.spend.push({ note: 'Planned basket (estimate)', amount: S.planned, date: new Date().toISOString().slice(0, 10) });
    S.list = []; S.planned = null; save(); S.tab = 'kitchen'; return render(); }
});
document.addEventListener('change', e => {
  const t = e.target, d = t.dataset || {};
  if (t.id === 'cat') { S.cat = t.value; render(); } else if (t.id === 'serv') { S.servings = Math.max(1, +t.value || 2); render(); }
  else if (t.id === 'bud') { S.budget = Math.max(0, +t.value || 0); save(); render(); }
  else if (d.done !== undefined) { S.list[+d.done].done = t.checked; save(); render(); }
  else if (d.qty !== undefined) { const v = parseFloat(t.value); if (v > 0) { S.list[+d.qty].qty = v; save(); render(); } }
});
document.addEventListener('input', e => { if (e.target.id === 'q') { S.q = e.target.value; clearTimeout(S.t); S.t = setTimeout(async () => { await render(); const q = $('#q'); q.focus(); q.setSelectionRange(99, 99); }, 250); } });
(async () => { try { CAT = await api('/api/catalog'); $('#demo').textContent = CAT.meta.demo ? CAT.meta.notice : ''; render(); }
  catch (e) { $('#view').innerHTML = '<div class="empty">Could not load the catalog. Start the server with <code>npm start</code>.</div>'; } })();
